$(document).ready(function () {
  // Activate WOW.js
  new WOW().init();
});

$(window).ready(function() {
  // Splash Screen
  $("#splash").fadeOut();
});
